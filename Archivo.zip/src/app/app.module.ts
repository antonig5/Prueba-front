import { Module } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from "src/auth/user.entity";
import { AuthModule } from "src/auth/auth.module";

@Module({
  imports: [TypeOrmModule.forRoot({
  type: 'mysql',
  host: 'localhost',
  port: 3306,
  username: 'root',
  password: '',
  database: 'base-nestjs',
  entities:[User],
  autoLoadEntities: true,
  synchronize: true,
  }),AuthModule ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
