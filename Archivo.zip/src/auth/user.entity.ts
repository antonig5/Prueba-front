import {Entity, Column, PrimaryGeneratedColumn} from 'typeorm'

@Entity()
export class User {
@PrimaryGeneratedColumn('increment')
id: number;

@Column({length: 255})
name: string;

@Column({length: 255})
email: string;

@Column({length: 255})
password: string;

@Column({type: 'boolean', default: true})
active: boolean;

@Column({type: 'boolean', default: false})
deleted: boolean;

@Column({type: 'timestamp'})
created_at: Date;

constructor() {
  this.id = 0;
  this.name = '';
  this.email = '';
  this.password = '';
  this.active = false;
  this.deleted = false;
  this.created_at = new Date();
}
}