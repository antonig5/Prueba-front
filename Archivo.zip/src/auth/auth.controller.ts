import { Controller, Post, Body, Get, Param } from '@nestjs/common';
import { AuthService } from './auth.service';

import { User } from './user.entity';

@Controller('auth')
export class AuthController {
    constructor(private readonly authService: AuthService) {} // Inyección de AuthService

    @Post('/register') // Ruta para registrar un usuario    
    async create(@Body() user: User): Promise<User> {
        return this.authService.create(user); // Llama al método create
    }

    @Get()
    async findAll(): Promise<User[]> {
        return this.authService.findAll(); // Llama al método findAll
    }

    @Get(':id')
    async findOne(@Param('id') id: number): Promise<User | null> {
        return this.authService.findOne(id); // Llama al método findOne
    }

    @Post('/remove/:id')
    async remove(@Param('id') id: number): Promise<void> {
        await this.authService.remove(id); // Llama al método remove
    }
}
